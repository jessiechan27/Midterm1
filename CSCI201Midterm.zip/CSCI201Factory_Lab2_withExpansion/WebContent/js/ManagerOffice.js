function ManagerOffice(cell, managerOffice) {
	// create and place image
	//var name = managerOffice['name'];
	var img = document.createElement('img');
	//img.id = name;
	img.src = 'img/ManagerOffice';
	cell.appendChild(img);
}